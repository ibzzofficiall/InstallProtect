<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Http\Requests\Admin\Settings\AdvancedSettingsFormRequest;

class AdvancedController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private Kernel $kernel,
        private SettingsRepositoryInterface $settings,
        private ViewFactory $view
    ) {
        $this->middleware(function ($request, $next) {
            $user = Auth::user();
            
            if (!$user || $user->id !== 1) {
                abort(403, 'Akses ditolak: Hanya Admin ID 1 yang dapat mengakses Advanced Settings! ©Protect By @Ibzz Official');
            }
            
            return $next($request);
        });
    }

    public function index(): View
    {
        return $this->view->make('admin.settings.advanced');
    }

    public function update(AdvancedSettingsFormRequest $request): RedirectResponse
    {
        foreach ($request->normalize() as $key => $value) {
            $this->settings->set('settings::' . $key, $value);
        }

        $this->kernel->call('queue:restart');
        $this->alert->success('Advanced settings were updated successfully and the queue worker was restarted.')->flash();

        return redirect()->route('admin.settings.advanced');
    }
}